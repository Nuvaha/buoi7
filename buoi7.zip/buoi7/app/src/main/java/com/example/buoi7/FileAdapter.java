package com.example.buoi7;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.FileHolder> {
    private List<File> data;
    private LayoutInflater inflater;

    public FileAdapter(Context context){
        inflater = LayoutInflater.from(context);
    }

    public void setData(List<File> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FileHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = inflater.inflate(R.layout.item_file, viewGroup, false);
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull FileHolder fileHolder, int i) {
        fileHolder.bindData(data.get(i));
    }

    @Override
    public int getItemCount() {
        return data == null ? 0 : data.size();
    }

    public class FileHolder extends RecyclerView.ViewHolder {
        private TextView tvName;
        private TextView tvDate;

        public FileHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_name);
            tvDate = itemView.findViewById(R.id.tv_date);
        }

        public void bindData(File f){
            tvName.setText(f.getName());
            tvDate.setText(f.getName());
        }
    }
}
