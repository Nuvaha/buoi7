package com.example.buoi7;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private FileManager manager;
    private List<File> arr;
    private final String[] PERMISSION_LIST = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager = new FileManager();
        if (checkPermission()) {
            readFile(manager.path);// cần có sự cấp phát của permission
        }else {
            requestPermissions(PERMISSION_LIST, 0);//Supperest
        }
    }

    private void initView(){

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (checkPermission()){
            readFile(manager.path);
        }else {
            finish();
        }
    }

    private boolean checkPermission(){
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
            return true;
        }
        for (String p: PERMISSION_LIST){
            // PackageManager.PERMISSION_GRANTED = accept
            // packageManager.PERMISSION_DENIED = enied
            int accept = checkSelfPermission(p);
            if (accept == PackageManager.PERMISSION_DENIED){
                return false;
            }
        }
        return true;
    }

    private void readFile(String path){
        arr = manager.getFile(path);
    }
}
